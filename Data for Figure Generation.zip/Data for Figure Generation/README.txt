Raw data for analysis purposes can be found at https://github.com/vincisLab/neuron-response-classification in 'GC temp.zip' (specifically contained within neuronDF)

Results used for statistical analysis and figure generation are included in this folder.